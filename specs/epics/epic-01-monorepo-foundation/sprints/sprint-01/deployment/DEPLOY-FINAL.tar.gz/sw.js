/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-c28420ab'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();

  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "test-video-converter.html",
    "revision": "05012ae39b46b014c0fa2ceb75e547bf"
  }, {
    "url": "registerSW.js",
    "revision": "a4648219d42384fac072e5a5014d3276"
  }, {
    "url": "pwa-512x512.png",
    "revision": "207b816325bed7f0bbae94b1d8479c20"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ef113664188bb7ff5a36f924e1311088"
  }, {
    "url": "mockServiceWorker.js",
    "revision": "94814070dbb6c9717faf37f2b306f5c5"
  }, {
    "url": "index.html",
    "revision": "1f180fbdd5fc95004ed0768d6f149fbe"
  }, {
    "url": "generate-icons.html",
    "revision": "d104b6ece7328231080d75c578298318"
  }, {
    "url": "ffmpeg-core.js",
    "revision": "7eb408858bd0f2e77817fda299b40be3"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "4c2ff90b4d2d4fa18d7571ed89a65a75"
  }, {
    "url": "images/banner.png",
    "revision": "8455c5aef13bc1437e6f96f53cb6b7a5"
  }, {
    "url": "assets/worker-BAOIWoxA.js",
    "revision": null
  }, {
    "url": "assets/virtual-vendor-CH52fURy.js",
    "revision": null
  }, {
    "url": "assets/ui-vendor-BRM84G8u.js",
    "revision": null
  }, {
    "url": "assets/react-vendor-C1-Qn4uC.js",
    "revision": null
  }, {
    "url": "assets/index-D_4QiAFU.js",
    "revision": null
  }, {
    "url": "assets/index-DUpNWwhc.css",
    "revision": null
  }, {
    "url": "assets/ffmpeg-vendor-l0sNRNKZ.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "4c2ff90b4d2d4fa18d7571ed89a65a75"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ef113664188bb7ff5a36f924e1311088"
  }, {
    "url": "pwa-512x512.png",
    "revision": "207b816325bed7f0bbae94b1d8479c20"
  }, {
    "url": "manifest.webmanifest",
    "revision": "6da18a2c14d8cb6e4c311eab587b6036"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/generativelanguage\.googleapis\.com\/.*/i, new workbox.NetworkFirst({
    "cacheName": "api-cache",
    "networkTimeoutSeconds": 10,
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 50,
      maxAgeSeconds: 300
    })]
  }), 'GET');

}));
//# sourceMappingURL=sw.js.map
