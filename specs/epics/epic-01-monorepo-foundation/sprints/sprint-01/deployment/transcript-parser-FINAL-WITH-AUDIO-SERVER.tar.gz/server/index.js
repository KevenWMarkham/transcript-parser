const express = require('express');
const multer = require('multer');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3001;

// Enable CORS for frontend
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['POST', 'GET'],
  allowedHeaders: ['Content-Type'],
}));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: '/tmp/uploads',
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.random().toString(36).substring(7)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm'];
    if (allowedTypes.includes(file.mimetype) || file.originalname.match(/\.(mp4|webm|mov|avi|mkv|mp3|wav|ogg|m4a)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Supported: mp4, webm, mov, avi, mkv, mp3, wav, ogg, m4a'));
    }
  }
});

// Ensure upload directory exists
if (!fs.existsSync('/tmp/uploads')) {
  fs.mkdirSync('/tmp/uploads', { recursive: true });
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'audio-extraction' });
});

// Audio extraction endpoint
app.post('/extract-audio', upload.single('video'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const inputPath = req.file.path;
  const outputPath = inputPath.replace(/\.[^.]+$/, '.m4a');

  console.log(`[FFmpeg] Processing: ${req.file.originalname}`);
  console.log(`[FFmpeg] Input: ${inputPath}`);
  console.log(`[FFmpeg] Output: ${outputPath}`);

  try {
    await extractAudio(inputPath, outputPath);

    // Read the output file
    const audioBuffer = fs.readFileSync(outputPath);

    // Clean up files
    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);

    console.log(`[FFmpeg] Success! Audio size: ${audioBuffer.length} bytes`);

    // Send audio file
    res.set({
      'Content-Type': 'audio/mp4',
      'Content-Length': audioBuffer.length,
      'Content-Disposition': 'attachment; filename="audio.m4a"'
    });
    res.send(audioBuffer);

  } catch (error) {
    console.error('[FFmpeg] Error:', error.message);

    // Clean up on error
    if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);

    res.status(500).json({ error: error.message });
  }
});

function extractAudio(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const args = [
      '-i', inputPath,
      '-vn',              // No video
      '-acodec', 'aac',   // AAC codec
      '-b:a', '64k',      // 64kbps bitrate
      '-ar', '22050',     // 22.05kHz sample rate
      '-y',               // Overwrite output
      outputPath
    ];

    console.log(`[FFmpeg] Running: ffmpeg ${args.join(' ')}`);

    const ffmpeg = spawn('ffmpeg', args);
    let stderr = '';

    ffmpeg.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    ffmpeg.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg exited with code ${code}: ${stderr.slice(-500)}`));
      }
    });

    ffmpeg.on('error', (err) => {
      reject(new Error(`Failed to start FFmpeg: ${err.message}`));
    });
  });
}

// Error handling middleware
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'File too large. Maximum size is 500MB.' });
    }
  }
  console.error('[Server] Error:', error.message);
  res.status(500).json({ error: error.message });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Audio extraction server running on port ${PORT}`);
});
