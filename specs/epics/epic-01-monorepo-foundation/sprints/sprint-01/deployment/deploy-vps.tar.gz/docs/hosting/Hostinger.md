# Hostinger VPS Hosting Information

**IMPORTANT: This file contains sensitive credentials and is excluded from version control**

## VPS Details

- **Plan**: KVM 2
- **IP Address**: 72.62.86.210
- **Location**: United States - Boston
- **Hostname**: srv1213378.hstgr.cloud

## Server Specifications

- **RAM**: 8 GB
- **CPU**: 2 cores
- **Storage**: 100 GB NVMe
- **Operating System**: Ubuntu 24.04 LTS
- **Monthly Cost**: $7.49/month

## SSH Access

```bash
ssh root@72.62.86.210
```

## Domain Configuration

- **Primary Domain**: smarthavenai.com
- **N8N Subdomain**: n8n.smarthavenai.com

### DNS Records to Configure

| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | @ | 72.62.86.210 | 3600 |
| A | www | 72.62.86.210 | 3600 |
| A | n8n | 72.62.86.210 | 3600 |

## Deployment Information

- **Repository**: https://github.com/your-username/transcript-parser
- **Deployment Path**: /var/www/smarthaven
- **Docker Compose**: Yes
- **Services**: App, N8N, PostgreSQL, Nginx, Certbot

## Access URLs (After Deployment)

- **Main App**: https://smarthavenai.com
- **N8N Workflows**: https://n8n.smarthavenai.com

## Setup Date

- **Created**: December 21, 2025
- **Status**: Active

## Notes

- VPS is running Ubuntu 24.04 LTS
- Docker deployment ready (see DOCKER_DEPLOYMENT.md in project root)
- SSL certificates will be obtained via Let's Encrypt/Certbot
- N8N and main app share PostgreSQL instance

## Hostinger API Integration

### MCP Server Setup

To manage Hostinger resources programmatically, you can use the Hostinger MCP server:

1. **Get API Token**:
   - Log into Hostinger control panel
   - Navigate to API section
   - Generate new API token

2. **Configure MCP Server**:
   - Copy `hostinger-mcp-config.json` to your Claude Code MCP configuration
   - Replace `ENTER_TOKEN_HERE` with your actual API token
   - Restart Claude Code to load the MCP server

3. **Available Capabilities**:
   - Manage DNS records programmatically
   - Monitor VPS status
   - Manage domains
   - Access deployment logs

See `hostinger-mcp-config.json` for the MCP server configuration.

## Next Steps

1. Update DNS records in Hostinger control panel (or use MCP server)
2. Wait 5-10 minutes for DNS propagation
3. SSH into server and follow DOCKER_DEPLOYMENT.md guide
4. Run deployment script or manual Docker setup
5. Configure SSL certificates
6. Access applications at URLs above
