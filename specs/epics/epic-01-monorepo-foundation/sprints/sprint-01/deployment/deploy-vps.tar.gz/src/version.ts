// App version - update this when deploying
export const APP_VERSION = '1.0.2-vps'
export const BUILD_DATE = '2024-12-22'
export const FFMPEG_MODE = 'multi-threaded (jsdelivr CDN)'
